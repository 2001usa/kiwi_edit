"""
Kawaii Branch Bot 1.0v

©️Kawaii Uz tomonidan yaratildi
-
🔸Botni ishga tushirish uchun:
    1. requirements.txt faylini pip orqali o‘rnating
    2. config.py faylini sozlang
    3. main.py faylini ishga tushiring
"""

# -----------------------------------------------
# Telegramda yopiq kanal oching. Kanal nomini "Trailers" ga o‘zgartiring.
# Botni admin qiling va kanal ID sini shu yerga yozing
trailers_base_chat = -1003837423161

# -----------------------------------------------
# Telegramda yopiq kanal oching. Kanal nomini "Series" ga o‘zgartiring.
# Botni admin qiling va kanal ID sini shu yerga yozing
series_base_chat = -1003837423161

# -----------------------------------------------
# @BotFather orqali olingan bot token
token = "7806141272:AAGEVUR13hRHFf5euquVYumk1Os_fAcBXcs"

# -----------------------------------------------
# Reklama uchun bog‘lanish username (@ belgisiz)
ads_manager_username = "aslbek_1203"

# -----------------------------------------------
# To‘liq admin uchun Telegram ID
bot_admin_id = 7586510077

# -----------------------------------------------
# Asosiy menyu rasmi
main_image = "https://img4.teletype.in/files/b1/fa/b1fa9624-f182-4da8-b918-0b33322e3df8.jpeg"
